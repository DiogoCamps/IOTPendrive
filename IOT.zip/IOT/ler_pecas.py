import network
from umqtt.simple import MQTTClient
from machine import Pin, time_pulse_us
from time import sleep
import ujson

# ======== CONFIGURAÇÕES ========
SSID = "WIFI_IOT_CFP601"
PASSWORD = "iot@senai601"
MQTT_BROKER = "10.110.22.6"
MQTT_PORT = 1883
MQTT_TOPIC_BASE = "fabrica/contador"
MQTT_CLIENT_ID = "esp32-contador-ultrassonico"


TRIG_PIN = 33  # saída do pulso
ECHO_PIN = 32  # entrada do pulao
     
# Distância limite para considerar detecção de peça (em cm)
DISTANCIA_LIMITE = 10
SOM_VELOCIDADE_CM_POR_US = 0.0343  # cm/us


def conectar_wifi(ssid, password):
    sta = network.WLAN(network.STA_IF)
    sta.active(True)
    if not sta.isconnected():
        print("Conectando à rede Wi-Fi...")
        sta.connect(ssid, password)
        while not sta.isconnected():
            print(".", end="")
            sleep(0.5)
    print("\nConectado ao Wi-Fi! IP:", sta.ifconfig()[0])

# ======== Função: Conectar ao Broker MQTT ========
def conectar_mqtt(client_id, broker):
    client = MQTTClient(client_id, broker, port=MQTT_PORT)
    while True:
        try:
            client.connect()
            print("Conectado ao broker MQTT!")
            return client
        except Exception as e:
            print("Erro ao conectar ao MQTT:", e)
            sleep(2)


def medir_distancia(trig, echo):
    trig.off()
    sleep(0.002)
    trig.on()
    sleep(0.00001)
    trig.off()
    LIMITE_ESPERA = 30000  # tempo máximo de espera
    duracao = time_pulse_us(echo, 1, LIMITE_ESPERA)
    if duracao < 0:
        return -1
    distancia = (duracao * SOM_VELOCIDADE_CM_POR_US) / 2
    return distancia


def publicar_mqtt(client, topic, mensagem):
    try:
        client.publish(topic, mensagem)
    except Exception as e:
        print("Erro ao publicar, tentando reconectar...", e)
        try:
            client.connect()
            client.publish(topic, mensagem)
            print("Reconectado e publicado com sucesso!")
        except:
            print("Falha ao reconectar ao MQTT.")


def main():
    conectar_wifi(SSID, PASSWORD)
    client = conectar_mqtt(MQTT_CLIENT_ID, MQTT_BROKER)

    trig = Pin(TRIG_PIN, Pin.OUT)
    echo = Pin(ECHO_PIN, Pin.IN)
    contador1 = 0
    contador2 = 1
    contador3 = 2
    estado_anterior = False

    MQTT_TOPIC = MQTT_TOPIC_BASE

    print("Aguardando 2 segundos...")
    sleep(2)

    while True:
        distancia = medir_distancia(trig, echo)
        if distancia < 0:
            print("Erro na leitura")
        else:
            print(f"Distância: {distancia:.2f} cm")
            if distancia <= DISTANCIA_LIMITE and not estado_anterior:
                contador1 = contador1 + 1
                contador2 = contador2 + 2
                contador3 = contador3 + 3
                estado_anterior = True
                
                vetor = [contador1, contador2, contador3]
                print(f"Peça detectada! Contagem c1: {contador1}")
                print(f"Peça detectada! Contagem c2: {contador2}")
                print(f"Peça detectada! Contagem c3: {contador3}")
               ## publicar_mqtt(client, MQTT_TOPIC, str(contador))
                publicar_mqtt(client, MQTT_TOPIC, ujson.dumps(vetor))
            elif distancia > DISTANCIA_LIMITE:
                estado_anterior = False

        sleep(0.2)

if __name__ == "__main__":
    main()